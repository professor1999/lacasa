cd "$(dirname "$BASH_SOURCE")"
  echo "Connecting to Discord..."
node index.js
