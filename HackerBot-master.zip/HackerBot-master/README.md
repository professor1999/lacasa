# The HackerBot has been depricated as of October 21, 2017

  
HackerBot has been renamed to Sunset. Sunset includes a load of new improvements over HackerBot.  
[Sunset Website](https://www.hacker-hub.com/sunset/)  
[HackerHub Website](https://www.hacker-hub.com/)   

_Yes I know it took me forever to edit this README, but in my defense, Sunset was too good of a bot to worry about HackerBot ;)_
